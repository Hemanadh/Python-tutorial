def add(a,b):
    """this function
adds two numbers"""
    return a+b


help(add)
