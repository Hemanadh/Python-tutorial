with open("abcd.txt","a") as f:
    f.write("hello")
print("Done")
