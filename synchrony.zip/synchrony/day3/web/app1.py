from flask import Flask,request,redirect,url_for
import datetime,os
import time
import sqlite3

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

@app.route('/synchrony')
def hello():
    return "Good morning from synchrony"

@app.route('/now')
def hell():
    return str(datetime.datetime.now())

@app.route('/env1')
def env1():
    output = "<table border=1>"
    for key,value in os.environ.items():
        output+="<tr><td>{}</td><td>{}</td></tr>".format(key,value)
    output += "</table>"
    return output

@app.route('/wish/<name>')
def wish(name):
    return "Good morning " + name

@app.route('/add/<a>/<b>')
def add(a,b):
    return str(int(a)+int(b))

@app.route('/fileinfo/<filename>')
def fileinfo(filename):
    size   = os.path.getsize(filename)
    ctime  = time.ctime(os.path.getctime(filename))
    return "The {} was created on {} and its size is {} bytes".format(filename,ctime,size)

@app.route("/cars")
def cars():
    output = "<table border=1>"
    conn = sqlite3.connect("mydatabase.db")
    cursor = conn.cursor()
    row = """<tr><td>{}</td><td>{}</td><td>{}</td>
             <td><a href="/remove/{}">X</a></td>
             <td><a href="/edit/{}">Modify</a></td></tr>
             """
    for cid,brand,price in cursor.execute("SELECT * FROM cars"):
        output+=row.format(cid,brand,price,cid,cid)
    conn.close()
    output+="</table>"
    return output + """<a href="/addcar">Add Car</a>"""
@app.route("/addcar")
def addcar():
    html="""
<form action='/addnewcar' method=post>
<input type=text name=cid>Car ID<br>
<input type=text name=brand>Brand<br>
<input type=text name=price>Price<br>
<input type=submit><br>
</form>
"""
    return html

@app.route("/addnewcar",methods=["POST"])
def addnewcar():
    cid = int(request.form.get("cid"))
    brand = request.form.get("brand")
    price = int(request.form.get("price"))
    
    #insert values in to the database
    conn = sqlite3.connect("mydatabase.db")
    cursor = conn.cursor()
    # insert some data
    sql = """INSERT INTO cars
    VALUES ({}, '{}',{})""".format(cid,brand,price)
    cursor.execute(sql)
    # save data to database
    conn.commit()
    conn.close()
    return redirect(url_for("cars"))

@app.route("/remove/<cid>")
def remove(cid):
    conn = sqlite3.connect("mydatabase.db")
    cursor = conn.cursor()
   
    sql = """DELETE FROM cars
    WHERE id = {}""".format(cid)
    cursor.execute(sql)
    # save data to database
    conn.commit()
    conn.close()
    return redirect(url_for("cars"))

@app.route("/edit/<cid>")
def edit(cid):
    conn = sqlite3.connect("mydatabase.db")
    cursor = conn.cursor()
    sql = "SELECT * FROM cars where id={}".format(cid)
    cursor.execute(sql)
    cid,brand,price = cursor.fetchone()
        
    conn.close()
    
   
    html="""
<form action='/updatecar' method=post>
<input type=text name=cid value={}>Car ID<br>
<input type=text name=brand value={}>Brand<br>
<input type=text name=price value={}>Price<br>
<input type=submit><br>
</form>""".format(cid,brand,price)
    return html

@app.route("/updatecar",methods=["POST"])
def updatecar():
    cid = int(request.form.get("cid"))
    brand = request.form.get("brand")
    price = int(request.form.get("price"))
    
    #insert values in to the database
    conn = sqlite3.connect("mydatabase.db")
    cursor = conn.cursor()
    # insert some data
    sql = """UPDATE cars SET
    carname = '{}', price = {} where id = {}""".format(brand,price,cid)
    cursor.execute(sql)
    # save data to database
    conn.commit()
    conn.close()
    return redirect(url_for("cars"))









