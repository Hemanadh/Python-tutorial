import re
#Search:searches only at the first instance of a string
#match: matches at the begining of the string


text="My mobile is 9866611005. My atm pin in 3456 9866611015 "

r=re.search('0?[7-9]\d{9}',text)
print("r.group()...",r.group())
print("r.span()...",r.span())


text1="My mobile is 9866611005. My atm pin in 3456"
r1=re.match('0?[7-9]\d{9}',text1)

print(r1)
text2="9866611005 is my mobile number"
r2=re.match('0?[7-9]\d{9}',text2)
print(r2.group())



