import re

mobile = re.compile(r'0?[7-9]\d{9}')
blankline = re.compile(r'^$')

#searching

text="My mobile is 9866611005. My atm pin in 3456"

r=mobile.search(text)
print(r.group())
print(r.span())

