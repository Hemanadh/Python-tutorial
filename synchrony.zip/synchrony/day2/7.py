import os
import glob
import zipfile

home    = "C:\\Users\\ABRIDGE0\\Desktop\\day2"
pattern = "*.py"
target  = "C:\\Users\\ABRIDGE0\\Desktop\\synchrony.zip"

os.chdir(home)
files2bzipped = glob.glob(pattern)
z = zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED)

for myfile in files2bzipped:
    z.write(myfile)
z.close()
