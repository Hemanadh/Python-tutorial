def division():
    s=1/0
try:
    division()
except ZeroDivsionError:
    print("number cannot be divided by zero")
    
    
