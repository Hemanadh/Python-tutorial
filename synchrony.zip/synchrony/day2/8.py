for x in range(10):
    print(x)
    if x == 6:
        break
else:
    print("done")
