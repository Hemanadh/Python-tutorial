import baby
class Toddler(baby.Baby):
    def sleep(self):
        print("la..la..laa")
    def cry(self):
        print("only folks in serials cry")

pinky=Toddler("Haritha")

pinky.laugh()
pinky.sleep()
pinky.cry()

