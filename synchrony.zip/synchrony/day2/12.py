import xlrd
wb = xlrd.open_workbook("marks.xls")
ws = wb.sheet_by_index(0)
for x in range(ws.nrows):
    print(ws.row_values(x))
   




