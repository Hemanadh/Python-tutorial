f=open("marks.csv","r")
for line in f:
    name,english,maths,science=line.split(",")
    average=(int(english)+int(maths)+int(science))/3
    print("The average of {} is {}".format(name,average))
f.close()
