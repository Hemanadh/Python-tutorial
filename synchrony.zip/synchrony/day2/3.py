import xlrd
wb = xlrd.open_workbook("titanic3.xls")
print(wb.nsheets)
print(wb.sheet_names())

ws = wb.sheet_by_name('titanic3')

print(ws.nrows)
print(ws.ncols)

for x in range(1310):
    print(ws.cell(x,2).value)

