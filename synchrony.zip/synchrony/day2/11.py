class Dog:
    def speak(self):print("bhou..bhou")
    def guard(self):print("I am guarding your home")

class Cat:
    def speak(self):print("meau..meau")
    def hunt(self):print("I am hunting mice")

class Doat(Dog,Cat):
    def speak(self):
        print("bhou..meau")
    def pspeak(self):
        super().speak()

ginger = Doat()

ginger.hunt()
ginger.guard()
ginger.speak()
ginger.pspeak()
