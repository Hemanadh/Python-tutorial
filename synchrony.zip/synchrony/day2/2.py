import xlwt
wb = xlwt.Workbook()
ws = wb.add_sheet("hyderabad")
ws2 = wb.add_sheet("synchrony")

ws.write(0,0,"India")
ws.write(0,1,"New Delhi")
ws.write(0,2,91)

ws.write(1,0,100)
ws.write(1,1,121)
ws.write(1,2,911)

wb.save("myfirst.xls")
