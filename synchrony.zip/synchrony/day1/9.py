#dictionaries
fate = {"TG":"TRS"
        ,"Chattisgarh":"Congress"
        ,"MP":"BJP"
        ,"RJ":"Congress"
        }

print(len(fate))

#read
print(fate["TG"])
print(fate.get("TG"))
#add
fate["AP"]="BJP"
print(len(fate))
print(fate.get("AP"))
#update
fate["AP"]="TDP"
print(fate.get("AP"))
#delete
del fate["AP"]
print(len(fate))


for state in fate:
    print(state,fate.get(state))



for state in fate:
    print("In {1} the leading party is {0}".format(fate.get(state),state))














