f=open("C:\\Users\\ABRIDGE0/Desktop/day1/numbers.txt","w")
for x in range(1,101):
    f.write(str(x) + "\n")
f.close()


