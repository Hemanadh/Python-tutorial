for x in range(10):
    print("I love you")
for x in range(10):
    print(x, "I love you")
for x in range(1,5):
    print(x)
for x in range(1,50,10):
    print(x)
for x in range(90,80,-2):
    print(x)

for x in "Hyderabad":
    print(x)

friends = ["hari","sujatha","ravi","sravan"]

for friend in friends:
    print(friend)
    
