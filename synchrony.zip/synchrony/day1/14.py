def mysum(*args):
    return sum(args)

print(mysum(10) == 10)
print(mysum(10,1) == 11)
print(mysum(10,1,2,3) == 16)
