f=open("C:\\Users\\ABRIDGE0/Desktop/day1/input.txt","r")
for line in f:
    print(line.rstrip().upper())
    print(len(line))
f.close()
