print("Good morning Hyderabad")
