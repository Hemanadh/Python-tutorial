#tuples
a=(3,4,4,5,6,8)
b=5,7,8,6
c=4,

print(type(a))
print(type(b))
print(type(c))

print(a.count(4))
print(b.index(8))

print(a.append(4))
