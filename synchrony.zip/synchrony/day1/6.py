city = "Hyderabad"

# indexing

print(city[0])
print(city[-1])

# slicing

print(city[1:5])
print(city[1:])
print(city[:5])

# operations

print(city + "hello")
print(city * 10)

# methods

print(city.lower())
print(city.upper())

print("hello how are you".capitalize())

# length

print(len(city))
