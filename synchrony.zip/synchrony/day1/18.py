f=open("sample.log","r")        #open the file
total=0
for line in f:                  #read line by line
    fields = line.split()       #split the line
    size = fields[-1]           #get the last field
    total += int(size)          #add all last fields
f.close()                       #close the file
print(total)
