def add(x=10,y=20):
    print( x+y)
add()
add(4)
add(4,5)

