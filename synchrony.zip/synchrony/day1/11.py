def getindices(string,char):
    list_of_positions=[]
    for pos in range(len(string)):
        if string[pos] == char:
                list_of_positions.append(pos)
    return list_of_positions

print(getindices("cisco","c"))
#[0,3]

def getindices1(string,char):
    list_of_positions=[]
    for index,mychr in enumerate(string):
        if mychr == char:
                list_of_positions.append(index)
    return list_of_positions
print(getindices1("cisco","c"))
