number = 45
guess = int(input("Enter your guess : "))
while True:
    if guess > number:
        print("Try a smaller number: ")
    elif guess < number:
        print("Try a bigger number: ")
    else:
        print("Congrats")
        break
    guess = int(input("Enter your guess : "))
