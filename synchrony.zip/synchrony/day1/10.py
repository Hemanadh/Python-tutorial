#circlearea(45)

def circlearea(r,pi=3.14):
    return pi*r*r


print(circlearea(45))
print(circlearea(45,3.1245566))

