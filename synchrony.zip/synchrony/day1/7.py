#working with lists
a=[45,78,34,56,12]

print(len(a))
print(min(a))
print(max(a))
print(sum(a))

#indexing
print(a[0])
print(a[-1])

#slicing

print(a[1:3])
print(sum(a[1:3]))
print(sum(a[-2:]))

# methods
print(a)
a.append(1000)
print(a)
a.insert(2,120)
print(a)

a.remove(78)
print(a)
a.pop()
print(a)


a.sort()
print(a)
a.reverse()
print(a)

print(a.count(12))
print(a.index(12))









